/* Dynamic RTL - Background service worker.
 * - Migrates legacy settings shape on install.
 * - Swaps the toolbar icon between the colored "active" version and the
 *   grayscale "inactive" version per tab, based on the per-site override.
 * - Handles popup commands.
 */
'use strict';

const api = (typeof chrome !== 'undefined' && chrome.runtime) ? chrome : browser;

const DEFAULT_SETTINGS = {
  mode: 'enable_all',
  siteOverrides: {},
  font: 'vazirmatn',
  customFontDataUrl: '',
  customFontName: '',
  customFontFormat: '',
  debug: false
};

// ----- Promisify ----------------------------------------------------------

function callAsync(fn, ctx, args) {
  return new Promise((resolve, reject) => {
    try {
      fn.call(ctx, ...args, (result) => {
        const err = api.runtime.lastError;
        if (err) reject(new Error(err.message || String(err)));
        else resolve(result);
      });
    } catch (e) { reject(e); }
  });
}
const tabsGet      = (id) => callAsync(api.tabs.get, api.tabs, [id]);
const tabsQuery    = (q)  => callAsync(api.tabs.query, api.tabs, [q]);
const storageGet   = (k)  => callAsync(api.storage.local.get, api.storage.local, [k]);
const storageSet   = (p)  => callAsync(api.storage.local.set, api.storage.local, [p]);
const storageRemove = (k) => callAsync(api.storage.local.remove, api.storage.local, [k]);

function setIcon(opts) {
  try {
    const ret = api.action.setIcon(opts);
    if (ret && typeof ret.then === 'function') return ret.catch(() => {});
  } catch (_) {}
  return Promise.resolve();
}
function clearBadge(tabId) {
  try {
    const ret = api.action.setBadgeText({ text: '', tabId });
    if (ret && typeof ret.then === 'function') return ret.catch(() => {});
  } catch (_) {}
  return Promise.resolve();
}

// ----- Helpers ------------------------------------------------------------

function normalizeHost(h) { return (h || '').toLowerCase().replace(/^www\./, ''); }

function findOverride(overrides, host) {
  if (!overrides) return null;
  host = normalizeHost(host);
  if (!host) return null;
  if (overrides[host]) return overrides[host];
  const parts = host.split('.');
  for (let i = 1; i < parts.length - 1; i++) {
    const parent = parts.slice(i).join('.');
    if (overrides[parent]) return overrides[parent];
  }
  return null;
}

function isSiteEnabled(settings, host) {
  const override = findOverride(settings.siteOverrides, host);
  if (override === 'on') return true;
  if (override === 'off') return false;
  return settings.mode === 'enable_all';
}

async function loadSettings() {
  const stored = await storageGet(null);
  return Object.assign({}, DEFAULT_SETTINGS, stored || {});
}

function getHostFromTab(tab) {
  try {
    if (!tab || !tab.url) return '';
    const u = new URL(tab.url);
    if (!/^https?:|^file:|^ftp:/.test(u.protocol)) return '';
    return u.hostname || '';
  } catch (_) { return ''; }
}

const ACTIVE_ICONS = {
  16: 'icons/icon-active-16.png',
  32: 'icons/icon-active-32.png',
  48: 'icons/icon-active-48.png',
  128: 'icons/icon-active-128.png'
};
const INACTIVE_ICONS = {
  16: 'icons/icon-inactive-16.png',
  32: 'icons/icon-inactive-32.png',
  48: 'icons/icon-inactive-48.png',
  128: 'icons/icon-inactive-128.png'
};

async function updateIconForTab(tab) {
  try {
    if (!tab || tab.id == null) return;
    const host = getHostFromTab(tab);
    // Always clear any leftover badge text from previous versions.
    await clearBadge(tab.id);
    if (!host) {
      await setIcon({ tabId: tab.id, path: INACTIVE_ICONS });
      return;
    }
    const settings = await loadSettings();
    const enabled = isSiteEnabled(settings, host);
    await setIcon({
      tabId: tab.id,
      path: enabled ? ACTIVE_ICONS : INACTIVE_ICONS
    });
  } catch (_) { /* tab gone */ }
}

async function refreshAllIcons() {
  try {
    const tabs = await tabsQuery({});
    await Promise.all(tabs.map(updateIconForTab));
  } catch (_) {}
}

// ----- Toggle ------------------------------------------------------------

async function toggleHostForCurrentTab(tabId) {
  let tab;
  try { tab = await tabsGet(tabId); } catch (_) { return { ok: false, reason: 'no-tab' }; }
  const host = getHostFromTab(tab);
  if (!host) return { ok: false, reason: 'no-host' };

  const settings = await loadSettings();
  const norm = normalizeHost(host);
  const overrides = Object.assign({}, settings.siteOverrides || {});

  // Determine the new state. If there's already an explicit override, flip
  // it. If not, set it to the opposite of the current effective state.
  const current = overrides[norm];
  let next;
  if (current === 'on') next = 'off';
  else if (current === 'off') next = 'on';
  else next = isSiteEnabled(settings, host) ? 'off' : 'on';
  overrides[norm] = next;

  await storageSet({ siteOverrides: overrides });
  await updateIconForTab(tab);
  try {
    api.tabs.sendMessage(tabId, { type: 'DYNRTL_RECONCILE' }, () => {
      void api.runtime.lastError;
    });
  } catch (_) {}
  return { ok: true, host: norm, state: next };
}

// ----- Migration ---------------------------------------------------------

async function migrateLegacySettings() {
  try {
    const stored = await storageGet(null);
    let needsMigrate = false;
    const patch = {};

    // Old shape used { exceptions: [...] } where the meaning depended on
    // "mode". Convert each entry into an explicit on/off override.
    if (Array.isArray(stored.exceptions) && stored.exceptions.length) {
      const overrides = Object.assign({}, stored.siteOverrides || {});
      const mode = stored.mode || DEFAULT_SETTINGS.mode;
      // exceptions held the inversion of the default
      const offValue = mode === 'enable_all' ? 'off' : 'on';
      for (const e of stored.exceptions) {
        const h = normalizeHost(e);
        if (h && !overrides[h]) overrides[h] = offValue;
      }
      patch.siteOverrides = overrides;
      needsMigrate = true;
    }

    if (needsMigrate) await storageSet(patch);

    // Drop legacy keys regardless.
    const legacyKeys = ['exceptions', 'enabled', 'autoDetectInputs'];
    const present = legacyKeys.filter(k => k in stored);
    if (present.length) await storageRemove(present);
  } catch (e) {
    console.error('[Dynamic RTL] migration error', e);
  }
}

async function seedDefaults() {
  try {
    const stored = await loadSettings();
    const patch = {};
    for (const k of Object.keys(DEFAULT_SETTINGS)) {
      if (stored[k] === undefined) patch[k] = DEFAULT_SETTINGS[k];
    }
    if (Object.keys(patch).length) await storageSet(patch);
  } catch (e) {
    console.error('[Dynamic RTL] seedDefaults error', e);
  }
}

// ----- Listeners ----------------------------------------------------------

api.runtime.onInstalled.addListener(async () => {
  await migrateLegacySettings();
  await seedDefaults();
  refreshAllIcons();
});

if (api.runtime.onStartup && api.runtime.onStartup.addListener) {
  api.runtime.onStartup.addListener(async () => {
    await migrateLegacySettings();
    refreshAllIcons();
  });
}

api.tabs.onActivated.addListener(async ({ tabId }) => {
  try {
    const tab = await tabsGet(tabId);
    updateIconForTab(tab);
  } catch (_) {}
});

api.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'loading' || changeInfo.url) {
    updateIconForTab(tab);
  }
});

api.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if ('siteOverrides' in changes || 'mode' in changes) {
    refreshAllIcons();
  }
});

api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return;
  switch (msg.type) {
    case 'DYNRTL_TOGGLE_CURRENT': {
      const tabId = msg.tabId || (sender.tab && sender.tab.id);
      if (tabId == null) { sendResponse({ ok: false, reason: 'no-tab' }); return true; }
      toggleHostForCurrentTab(tabId).then(sendResponse).catch(e => {
        sendResponse({ ok: false, reason: 'error', error: String(e) });
      });
      return true;
    }
    case 'DYNRTL_REFRESH_ICONS':
      refreshAllIcons().then(() => sendResponse({ ok: true }));
      return true;
    default:
      return;
  }
});
