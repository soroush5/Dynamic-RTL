/* Dynamic RTL - Core utilities (shared between content scripts and pages).
 * Provides defaults, regex, host helpers, and the per-site override resolver.
 */
(function () {
  'use strict';

  if (window.__DYNRTL_CORE__) return;

  const api = (typeof chrome !== 'undefined' && chrome.runtime) ? chrome : browser;

  /* Persian / Arabic detection.
   * Covers:
   *   U+0600-U+06FF  Arabic
   *   U+0750-U+077F  Arabic Supplement
   *   U+08A0-U+08FF  Arabic Extended-A
   *   U+FB50-U+FDFF  Arabic Presentation Forms-A
   *   U+FE70-U+FEFF  Arabic Presentation Forms-B
   * Persian-specific glyphs (پ چ ژ گ) live inside U+0600-U+06FF.
   */
  const RTL_REGEX = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/;

  // Tags whose text we never touch.
  const SKIP_TAGS = new Set([
    'SCRIPT', 'STYLE', 'NOSCRIPT', 'IFRAME', 'OBJECT', 'EMBED',
    'CANVAS', 'SVG', 'VIDEO', 'AUDIO', 'CODE', 'PRE', 'KBD', 'SAMP',
    'TT', 'XMP', 'TEMPLATE'
  ]);

  // CSS selectors of canvas-driven editors / sites where DOM RTL would either
  // no-op or break things. We still process surrounding chrome.
  const SKIP_SELECTORS = [
    '.kix-page',
    '.kix-canvas-tile-content',
    '.docs-texteventtarget-iframe',
    '.waffle',
    '.punch-viewer',
    '.CodeMirror',
    '.monaco-editor',
    '.ace_editor'
  ];

  const DEFAULT_SETTINGS = {
    mode: 'enable_all',           // 'enable_all' | 'disable_all' - applies to sites without an explicit override
    siteOverrides: {},            // map of normalized hostname -> 'on' | 'off'
    font: 'vazirmatn',            // 'vazirmatn' | 'custom'
    customFontDataUrl: '',
    customFontName: '',
    customFontFormat: '',
    debug: false
  };

  function normalizeHost(h) {
    return (h || '').toLowerCase().replace(/^www\./, '');
  }

  // Resolves the on/off override for a host, walking up the DNS tree so
  // adding "google.com" automatically covers "mail.google.com" too unless
  // the subdomain has its own explicit entry.
  function findOverride(overrides, host) {
    if (!overrides) return null;
    host = normalizeHost(host);
    if (!host) return null;
    if (overrides[host]) return overrides[host];
    const parts = host.split('.');
    for (let i = 1; i < parts.length - 1; i++) {
      const parent = parts.slice(i).join('.');
      if (overrides[parent]) return overrides[parent];
    }
    return null;
  }

  function isSiteEnabled(settings, host) {
    const override = findOverride(settings.siteOverrides, host);
    if (override === 'on') return true;
    if (override === 'off') return false;
    return settings.mode === 'enable_all';
  }

  // Logger: errors always print, info / warn only when debug is on.
  function makeLogger(getDebug) {
    const tag = '%c[Dynamic RTL]';
    const style = 'color:#fff;background:#5b6cff;border-radius:3px;padding:1px 4px;font-weight:bold';
    return {
      log(...args) { if (getDebug()) console.log(tag, style, ...args); },
      info(...args) { if (getDebug()) console.info(tag, style, ...args); },
      warn(...args) { if (getDebug()) console.warn(tag, style, ...args); },
      error(...args) { console.error(tag, style, ...args); }
    };
  }

  window.__DYNRTL_CORE__ = {
    api,
    RTL_REGEX,
    SKIP_TAGS,
    SKIP_SELECTORS,
    DEFAULT_SETTINGS,
    normalizeHost,
    findOverride,
    isSiteEnabled,
    makeLogger
  };
})();
