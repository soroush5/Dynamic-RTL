/* Dynamic RTL - Early injector
 * Runs at document_start so the font + base styling are registered before
 * the first paint. Avoids the "flash of LTR" effect.
 */
(function () {
  'use strict';

  if (window.__DYNRTL_EARLY_DONE__) return;
  window.__DYNRTL_EARLY_DONE__ = true;

  const api = (typeof chrome !== 'undefined' && chrome.runtime) ? chrome : browser;

  let fontUrl = '';
  try { fontUrl = api.runtime.getURL('fonts/Vazirmatn-Variable.woff2'); } catch (_) {}

  const css = `
@font-face {
  font-family: 'Vazirmatn DynRTL';
  src: url("${fontUrl}") format('woff2-variations'),
       url("${fontUrl}") format('woff2');
  font-weight: 100 900;
  font-style: normal;
  font-display: swap;
}

:root {
  --dynrtl-font-stack: 'Vazirmatn DynRTL', 'Vazirmatn', 'Tahoma', 'Segoe UI', sans-serif;
}

/* Display containers with Persian / Arabic text get full RTL treatment. */
.dynrtl-rtl {
  direction: rtl !important;
  text-align: right !important;
  font-family: var(--dynrtl-font-stack) !important;
}

/* Inside an RTL-tagged display block, code-like inline tokens are by
   convention always LTR regardless of content. */
.dynrtl-rtl code,
.dynrtl-rtl kbd,
.dynrtl-rtl samp,
.dynrtl-rtl var,
.dynrtl-rtl tt,
.dynrtl-rtl pre,
.dynrtl-rtl [data-dynrtl-keep-ltr] {
  direction: ltr !important;
  unicode-bidi: isolate !important;
  text-align: initial !important;
}

/* Links and citations get plaintext bidi: each one is its own isolated
   bidi context whose direction is auto-detected from its first strong
   character. This keeps a Google search result's URL flowing LTR even
   when its surrounding result block is RTL, AND lets a fully-Persian
   URL like https://fa.wikipedia.org/wiki/تهران render correctly
   (the "تهران" portion stays in proper Persian order, while the
   English part of the URL stays in English order). It also stops one
   Persian URL from corrupting the layout of neighbouring results.

   Compared to a hard "direction: ltr !important", plaintext bidi
   handles the mixed-script case the bidi spec was designed for. */
.dynrtl-rtl a,
.dynrtl-rtl cite,
.dynrtl-rtl [role="link"] {
  unicode-bidi: plaintext !important;
  text-align: initial !important;
}

/* Inputs / textareas / contenteditable use the dir="auto" HTML attribute
   instead of CSS for direction (much safer for editor frameworks like
   ProseMirror, Lexical, Slate used by Claude, Notion, X, etc.). We set
   dir="auto" exactly once when an editable is first focused and never
   touch it again - reacting on every keystroke makes editors fight us
   and freezes the tab.

   text-align:start then follows whatever direction dir="auto" resolves
   to (right for Persian/Arabic content, left for Latin), so alignment is
   correct with zero per-keystroke JavaScript. We use !important because
   many sites pin text-align:left on their inputs. */
.dynrtl-rtl-input {
  font-family: var(--dynrtl-font-stack) !important;
  text-align: start !important;
}

/* Retained for backward compatibility with older tagged DOM; no longer
   applied by the content script. */
.dynrtl-rtl-input-aligned {
  text-align: right !important;
}

[data-dynrtl-skip], [data-dynrtl-skip] * {
  direction: ltr !important;
  text-align: initial !important;
  font-family: inherit !important;
}
`;

  function inject() {
    if (document.getElementById('dynrtl-base-style')) return;
    const style = document.createElement('style');
    style.id = 'dynrtl-base-style';
    style.setAttribute('data-dynrtl', 'base');
    style.textContent = css;
    const target = document.head || document.documentElement;
    if (target) target.appendChild(style);
  }

  inject();
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', inject, { once: true });
  }
})();
