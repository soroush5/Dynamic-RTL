/* Dynamic RTL - Main content script.
 * Detects Persian / Arabic text, applies the .dynrtl-rtl class to display
 * containers, and uses dir="auto" + dynamic text-align for editable
 * elements (safer for editor frameworks). Walks shadow DOM. Observes
 * DOM additions for SPAs and chat apps.
 *
 * ─────────────────────────────────────────────────────────────────────
 * Why this script is built the way it is (the freeze story)
 * ─────────────────────────────────────────────────────────────────────
 * Sites like chatgpt.com and claude.ai are React apps that:
 *   - re-render constantly (reconciliation replaces real DOM nodes),
 *   - run their own ResizeObserver / IntersectionObserver on message
 *     nodes for autoscroll + virtualization,
 *   - stream output by adding many small block nodes per second.
 *
 * When we apply `direction:rtl + font-family` to a node, its measured
 * size changes. The app's ResizeObserver reacts -> React re-renders ->
 * brand-new DOM nodes appear -> our MutationObserver fires -> we tag the
 * new nodes -> their size changes -> ... A self-sustaining feedback loop
 * that pins the main thread at 100% and freezes the tab. No amount of
 * "make each step cheaper" fixes a loop that never terminates.
 *
 * The only robust cure is to make the extension *self-limiting* so it can
 * never occupy more than a bounded slice of the main thread no matter
 * what the page does:
 *
 *   1. CIRCUIT BREAKER. The MutationObserver does almost nothing itself -
 *      it just records that work is pending and, crucially, COUNTS how
 *      noisy the page is. When a burst is too large, or we trip the
 *      breaker too often in a short window, we fully DISCONNECT every
 *      observer for a cooldown (growing 0.8s -> 6s). While disconnected
 *      our main-thread cost is exactly zero, which definitively breaks
 *      the feedback loop. After the cooldown we reconnect and do ONE
 *      catch-up walk of the body (cheap: already-tagged subtrees bail in
 *      a few pointer hops).
 *
 *   2. TRAILING DEBOUNCE. Normal mutations are coalesced and processed at
 *      most once per quiet period, never synchronously inside the
 *      observer callback.
 *
 *   3. TIME + NODE BUDGET per flush, then yield. A flush can never run
 *      longer than FLUSH_BUDGET_MS or tag more than WALK_TEXT_BUDGET
 *      nodes before handing the thread back.
 *
 *   4. We never observe characterData (token-by-token streaming noise),
 *      never tag landmark/region elements or large layout containers
 *      (tagging them relayouts the whole app shell), memoise the
 *      expensive skip check, and find text + shadow hosts in a single
 *      TreeWalker pass (no querySelectorAll('*')).
 */
(function () {
  'use strict';

  if (window.__DYNRTL_MAIN_DONE__) return;
  window.__DYNRTL_MAIN_DONE__ = true;

  const core = window.__DYNRTL_CORE__;
  if (!core) return;

  const {
    api, RTL_REGEX, SKIP_TAGS, SKIP_SELECTORS,
    DEFAULT_SETTINGS, isSiteEnabled, makeLogger
  } = core;

  // ----- State ----------------------------------------------------------
  let settings = Object.assign({}, DEFAULT_SETTINGS);
  let active = false;
  const tagged = new WeakSet();
  const markedInputs = new WeakSet(); // editable elements already set up (dir + font), never re-touched
  let shadowRoots = new WeakSet(); // shadow roots we've attached an observer to (reset on cooldown)
  const skippableCache = new WeakMap(); // el -> boolean (memoised isSkippableElement)

  const dirtyRoots = new Set();    // elements/subtrees waiting to be walked
  let flushTimer = null;           // trailing-debounce timer id
  let flushQueued = false;         // an idle flush is already queued
  let observers = [];              // [light dom observer, shadow root observers...]
  let inputHandlerAttached = false;

  // Circuit-breaker state.
  let cooldownActive = false;      // observers disconnected, waiting to recover
  let cooldownTimer = null;
  let cooldownLevel = 0;           // grows each time we trip; controls backoff
  let recentTrips = [];            // timestamps of recent breaker trips (rolling window)

  const log = makeLogger(() => settings.debug);

  // ----- Tunables -------------------------------------------------------

  // Trailing-debounce window: collect mutations for this long before
  // doing any work. Small enough to feel instant, large enough to
  // coalesce a render burst into one pass.
  const DEBOUNCE_MS = 150;

  // A single observer callback carrying more than this many records is
  // treated as a "storm" and trips the breaker immediately.
  const STORM_RECORDS = 60;

  // Per-flush ceilings. Once either is hit we requeue the rest and yield.
  const WALK_TEXT_BUDGET = 1500;   // text nodes accepted per flush
  const FLUSH_BUDGET_MS = 12;      // wall-clock per flush

  // If a flush itself runs longer than this it counts as "heavy" and
  // contributes to tripping the breaker.
  const HEAVY_FLUSH_MS = 16;

  // How many breaker trips inside TRIP_WINDOW_MS before we consider the
  // page pathological and escalate the cooldown aggressively.
  const TRIP_WINDOW_MS = 4000;
  const TRIPS_BEFORE_ESCALATE = 3;

  // Cooldown backoff bounds.
  const COOLDOWN_BASE_MS = 800;
  const COOLDOWN_MAX_MS = 6000;
  const MAX_COOLDOWN_LEVEL = 8;

  // How far up the tree we walk to detect an already-tagged ancestor.
  const ANCESTOR_LOOKUP_DEPTH = 8;

  // Never tag an element with more than this many direct children -
  // it's a layout container, not a text block.
  const MAX_CHILDREN_TO_TAG = 200;

  const now = () => performance.now();

  const idle = window.requestIdleCallback
    ? (cb) => window.requestIdleCallback(cb, { timeout: 200 })
    : (cb) => setTimeout(cb, 32);

  // ----- Element helpers -----------------------------------------------

  function isSkippableElementRaw(el) {
    if (!el || el.nodeType !== 1) return true;
    const tag = el.tagName;
    if (tag && SKIP_TAGS.has(tag)) return true;
    if (el.hasAttribute && el.hasAttribute('data-dynrtl-skip')) return true;
    if (el.closest) {
      for (let i = 0; i < SKIP_SELECTORS.length; i++) {
        try {
          if (el.closest(SKIP_SELECTORS[i])) return true;
        } catch (_) { /* invalid selector for this node - ignore */ }
      }
    }
    return false;
  }

  function isSkippableElement(el) {
    if (!el || el.nodeType !== 1) return true;
    const cached = skippableCache.get(el);
    if (cached !== undefined) return cached;
    const v = isSkippableElementRaw(el);
    skippableCache.set(el, v);
    return v;
  }

  // True when the element is part of an editing region. We require an
  // explicit contenteditable=true|""|plaintext-only on a CLOSE ancestor
  // (within 6 hops) to avoid false positives on apps that put a global
  // contenteditable=false on the whole shell.
  function isInsideEditor(el) {
    let cur = el;
    for (let i = 0; cur && cur.nodeType === 1 && i < 6; i++) {
      const ce = cur.getAttribute && cur.getAttribute('contenteditable');
      if (ce === 'false') return false;
      if (ce === 'true' || ce === '' || ce === 'plaintext-only') return true;
      cur = cur.parentNode;
    }
    return false;
  }

  // Cheap O(8) check: is this element already inside a tagged subtree?
  function hasTaggedAncestor(el) {
    let cur = el;
    for (let i = 0; cur && i < ANCESTOR_LOOKUP_DEPTH; i++) {
      if (tagged.has(cur)) return true;
      cur = cur.parentElement;
    }
    return false;
  }

  // Inline tag list - used to walk up to the nearest block ancestor.
  const INLINE_TAGS = new Set([
    'A','ABBR','B','BDI','BDO','BIG','BR','CITE','CODE','DATA','DFN','EM',
    'I','KBD','MARK','Q','S','SAMP','SMALL','SPAN','STRONG','SUB','SUP',
    'TIME','U','VAR','WBR','FONT','LABEL'
  ]);

  // Landmark / region tags. We never tag these and never let
  // findBlockAncestor walk PAST them - tagging a landmark applies RTL +
  // font to the whole app shell and forces a full-document relayout.
  const LANDMARK_TAGS = new Set([
    'BODY', 'HTML', 'HEAD',
    'MAIN', 'NAV', 'HEADER', 'FOOTER', 'ASIDE',
    'SECTION', 'ARTICLE', 'DIALOG', 'FORM'
  ]);

  function findBlockAncestor(el) {
    if (!el) return null;
    let cur = el;
    let lastInline = null;
    for (let i = 0; cur && i < 5; i++) {
      if (cur.nodeType !== 1) { cur = cur.parentNode; continue; }
      if (LANDMARK_TAGS.has(cur.tagName)) return lastInline;
      if (!INLINE_TAGS.has(cur.tagName)) return cur;
      lastInline = cur;
      cur = cur.parentNode;
    }
    return null;
  }

  // ----- Tagging --------------------------------------------------------

  function tagElement(el) {
    if (!el || el.nodeType !== 1) return;
    if (tagged.has(el)) return;
    if (LANDMARK_TAGS.has(el.tagName)) return;
    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') return;
    if (isInsideEditor(el)) return;
    if (el.children && el.children.length > MAX_CHILDREN_TO_TAG) return;
    el.classList.add('dynrtl-rtl');
    tagged.add(el);
  }

  function processTextNode(textNode) {
    const v = textNode.nodeValue;
    if (!v) return;
    if (!RTL_REGEX.test(v)) return;
    const parent = textNode.parentElement;
    if (!parent) return;
    if (hasTaggedAncestor(parent)) return;
    if (isSkippableElement(parent)) return;
    if (isInsideEditor(parent)) return;
    const target = findBlockAncestor(parent);
    if (!target) return;
    tagElement(target);
  }

  // Single-pass walker: finds Persian / Arabic text nodes AND shadow
  // hosts in one TreeWalker traversal. Returns remaining text budget.
  function walkLightSubtree(root, budget, shadowOut) {
    if (!root) return budget;
    if (root.nodeType === 1 && isSkippableElement(root)) return budget;
    let tw;
    try {
      tw = document.createTreeWalker(
        root,
        NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT,
        {
          acceptNode(node) {
            if (node.nodeType === 1) {
              if (isSkippableElement(node)) return NodeFilter.FILTER_REJECT;
              if (node.shadowRoot && !shadowRoots.has(node.shadowRoot)) {
                shadowOut.push(node.shadowRoot);
              }
              return NodeFilter.FILTER_SKIP;
            }
            const p = node.parentElement;
            if (!p) return NodeFilter.FILTER_REJECT;
            if (hasTaggedAncestor(p)) return NodeFilter.FILTER_REJECT;
            if (isSkippableElement(p)) return NodeFilter.FILTER_REJECT;
            if (isInsideEditor(p)) return NodeFilter.FILTER_REJECT;
            if (!node.nodeValue) return NodeFilter.FILTER_REJECT;
            return RTL_REGEX.test(node.nodeValue)
              ? NodeFilter.FILTER_ACCEPT
              : NodeFilter.FILTER_SKIP;
          }
        }
      );
    } catch (_) {
      return budget;
    }
    let n;
    while ((n = tw.nextNode())) {
      processTextNode(n);
      if (--budget <= 0) return budget;
    }
    return budget;
  }

  function walkSubtree(root, budget) {
    if (typeof budget !== 'number') budget = WALK_TEXT_BUDGET;
    if (!root) return budget;
    const stack = [root];
    while (stack.length) {
      const node = stack.pop();
      if (!node) continue;
      const shadowOut = [];
      if (node.nodeType === 1 || node.nodeType === 11) {
        budget = walkLightSubtree(node, budget, shadowOut);
        if (budget <= 0) return budget;
        for (let i = 0; i < shadowOut.length; i++) {
          const sr = shadowOut[i];
          attachShadowObserver(sr);
          stack.push(sr);
        }
      } else if (node.nodeType === 3 && node.parentElement) {
        processTextNode(node);
      }
    }
    return budget;
  }

  // ----- Inputs / textarea / contenteditable ---------------------------
  //
  // CRITICAL: this path is NOT behind the circuit breaker - it runs
  // synchronously on DOM events. Editor frameworks (ProseMirror, Lexical,
  // Slate used by ChatGPT, Claude, Notion, X, Gemini, ...) run their OWN
  // MutationObserver on their contenteditable root and will fight any
  // per-keystroke attribute/class churn we introduce, producing an
  // input -> our-write -> their-resync -> input -> ... loop that freezes
  // the tab (e.g. pressing Shift+Enter for a newline).
  //
  // So we do the absolute minimum, ONCE per element, and never on every
  // keystroke:
  //   - set dir="auto" only if the site has not set dir itself (so we
  //     never fight a site that manages direction), and
  //   - add a font class that also sets `text-align: start`.
  // dir="auto" makes the browser pick direction from the content
  // natively, and `text-align: start` then follows that direction with
  // zero JavaScript. No content reads, no class toggling, no work on
  // input/keydown at all.

  function applyInputDir(el) {
    if (!el || el.nodeType !== 1) return;
    if (isSkippableElement(el)) return;
    if (markedInputs.has(el)) return; // already handled once - do nothing
    markedInputs.add(el);
    try {
      if (!el.hasAttribute('dir')) el.setAttribute('dir', 'auto');
    } catch (_) {}
    try {
      if (!el.classList.contains('dynrtl-rtl-input')) {
        el.classList.add('dynrtl-rtl-input');
      }
    } catch (_) {}
  }

  // We only listen on focusin. An input is set up once when it first
  // receives focus; after that dir="auto" + text-align:start handle
  // every subsequent keystroke natively. We deliberately do NOT listen
  // to the `input` event - reacting on every keystroke is what hung the
  // editor on Shift+Enter.
  function handleFocusEvent(ev) {
    const t = ev.target;
    if (!t || t.nodeType !== 1) return;
    const tag = t.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA' || t.isContentEditable) {
      applyInputDir(t);
    }
  }

  function attachInputHandler() {
    if (inputHandlerAttached) return;
    inputHandlerAttached = true;
    document.addEventListener('focusin', handleFocusEvent, true);
  }

  function detachInputHandler() {
    if (!inputHandlerAttached) return;
    inputHandlerAttached = false;
    document.removeEventListener('focusin', handleFocusEvent, true);
  }

  function sweepInputs(root) {
    const r = root && root.querySelectorAll ? root : document;
    if (!r.querySelectorAll) return;
    let nodes;
    try {
      nodes = r.querySelectorAll(
        'input, textarea, [contenteditable=""], [contenteditable="true"], [contenteditable="plaintext-only"]'
      );
    } catch (_) {
      return;
    }
    for (let i = 0; i < nodes.length; i++) applyInputDir(nodes[i]);
  }

  // ----- Work queue + scheduling ---------------------------------------

  function markDirty(el) {
    if (!el) return;
    // While the queue is huge there is no point tracking individual
    // subtrees - a single body walk covers them all and is budgeted.
    if (dirtyRoots.size > 256) {
      dirtyRoots.clear();
      const root = document.body || document.documentElement;
      if (root) dirtyRoots.add(root);
      return;
    }
    dirtyRoots.add(el);
  }

  // Trailing debounce -> idle -> flush. Never runs synchronously inside
  // the observer callback.
  function scheduleFlush() {
    if (cooldownActive || flushQueued || flushTimer) return;
    flushTimer = setTimeout(() => {
      flushTimer = null;
      flushQueued = true;
      idle(flush);
    }, DEBOUNCE_MS);
  }

  function flush() {
    flushQueued = false;
    if (!active || cooldownActive) return;
    const t0 = now();
    const list = Array.from(dirtyRoots);
    dirtyRoots.clear();
    let budget = WALK_TEXT_BUDGET;
    let overBudget = false;
    for (let i = 0; i < list.length; i++) {
      const el = list[i];
      if (!el) continue;
      if (el.nodeType === 1 && !el.isConnected) continue; // stale (re-rendered away)
      try {
        budget = walkSubtree(el, budget);
      } catch (e) { log.error('walk failed', e); }
      if (budget <= 0 || now() - t0 > FLUSH_BUDGET_MS) {
        for (let j = i + 1; j < list.length; j++) {
          if (list[j]) dirtyRoots.add(list[j]);
        }
        overBudget = true;
        break;
      }
    }
    const dur = now() - t0;
    log.log('flush', dur.toFixed(1) + 'ms', 'remaining', dirtyRoots.size);

    // A flush that blew the budget AND took real wall-clock time is a
    // signal the page is fighting us (feedback loop) or is enormous.
    // Trip the breaker rather than spin.
    if (overBudget && dur >= HEAVY_FLUSH_MS) {
      tripBreaker('heavy flush ' + dur.toFixed(0) + 'ms');
      return;
    }
    if (dirtyRoots.size) scheduleFlush();
  }

  // ----- Circuit breaker -----------------------------------------------

  function tripBreaker(reason) {
    const t = now();
    recentTrips.push(t);
    recentTrips = recentTrips.filter((x) => t - x < TRIP_WINDOW_MS);

    // Escalate the backoff when we keep tripping in a short window.
    if (recentTrips.length >= TRIPS_BEFORE_ESCALATE) {
      cooldownLevel = Math.min(cooldownLevel + 2, MAX_COOLDOWN_LEVEL);
    } else {
      cooldownLevel = Math.min(cooldownLevel + 1, MAX_COOLDOWN_LEVEL);
    }

    const wait = Math.min(
      COOLDOWN_BASE_MS * Math.pow(2, cooldownLevel - 1),
      COOLDOWN_MAX_MS
    );

    cooldownActive = true;
    stopObservers();                 // zero main-thread cost while cooling
    if (flushTimer) { clearTimeout(flushTimer); flushTimer = null; }
    flushQueued = false;
    dirtyRoots.clear();

    log.warn('circuit breaker tripped:', reason,
      '| level', cooldownLevel, '| cooldown', wait + 'ms');

    if (cooldownTimer) clearTimeout(cooldownTimer);
    cooldownTimer = setTimeout(endCooldown, wait);
  }

  function endCooldown() {
    cooldownTimer = null;
    if (!active) { cooldownActive = false; return; }
    cooldownActive = false;
    // Shadow observers were disconnected; let the catch-up walk
    // re-discover and re-attach them.
    shadowRoots = new WeakSet();
    startObservers();
    // One catch-up walk of the whole body. Cheap: every already-tagged
    // subtree bails immediately via hasTaggedAncestor.
    const root = document.body || document.documentElement;
    if (root) {
      dirtyRoots.add(root);
      flushQueued = true;
      idle(flush);
    }
    log.log('cooldown ended; observers reconnected');
  }

  // Let the cooldown level decay while the page is calm, so a page that
  // is only briefly busy recovers full responsiveness afterwards.
  function maybeDecayCooldown() {
    if (cooldownLevel > 0 && recentTrips.length === 0) {
      cooldownLevel = Math.max(0, cooldownLevel - 1);
    }
    recentTrips = recentTrips.filter((x) => now() - x < TRIP_WINDOW_MS);
  }

  // ----- MutationObserver ----------------------------------------------
  //
  // The callback is deliberately minimal: detect storms, collect dirty
  // roots, schedule a debounced flush. No walking, no tagging here.

  function observerCallback(mutations) {
    if (!active || cooldownActive) return;

    if (mutations.length > STORM_RECORDS) {
      tripBreaker('mutation storm ' + mutations.length + ' records');
      return;
    }

    let sawWork = false;
    for (let i = 0; i < mutations.length; i++) {
      const m = mutations[i];
      if (m.type !== 'childList') continue;
      const added = m.addedNodes;
      for (let j = 0; j < added.length; j++) {
        const n = added[j];
        if (n.nodeType === 1) {
          // Skip the entire editor subtree. Editable elements are set
          // up once via focusin (dir="auto"); their internal typing
          // churn (e.g. ProseMirror/Lexical inserting a newline on
          // Shift+Enter) must never enter our work queue or we would
          // walk it on every keystroke and fight the editor's own
          // MutationObserver.
          if (isInsideEditor(n)) continue;
          if (n.parentElement && hasTaggedAncestor(n.parentElement)) continue;
          if (isSkippableElement(n)) continue;
          markDirty(n);
          sawWork = true;
          if (n.shadowRoot) {
            attachShadowObserver(n.shadowRoot);
            markDirty(n.shadowRoot);
          }
        } else if (n.nodeType === 3 && n.parentElement) {
          const p = n.parentElement;
          if (!hasTaggedAncestor(p) && !isInsideEditor(p)) {
            markDirty(p);
            sawWork = true;
          }
        }
      }
    }
    if (sawWork) {
      maybeDecayCooldown();
      scheduleFlush();
    }
  }

  function attachShadowObserver(shadowRoot) {
    if (!shadowRoot || shadowRoots.has(shadowRoot)) return;
    shadowRoots.add(shadowRoot);
    try {
      const mo = new MutationObserver(observerCallback);
      mo.observe(shadowRoot, { subtree: true, childList: true });
      observers.push(mo);
      log.log('shadow observer attached');
    } catch (e) {
      log.error('failed to observe shadow root', e);
    }
  }

  function startObservers() {
    if (observers.length) return;
    const target = document.body || document.documentElement;
    if (!target) return;
    const mo = new MutationObserver(observerCallback);
    mo.observe(target, { subtree: true, childList: true });
    observers.push(mo);
    log.log('observer started');
  }

  function stopObservers() {
    for (const mo of observers) {
      try { mo.disconnect(); } catch (_) {}
    }
    observers = [];
  }

  // ----- Custom font ---------------------------------------------------

  function applyCustomFont() {
    const id = 'dynrtl-custom-font-style';
    let style = document.getElementById(id);
    if (settings.font === 'custom' && settings.customFontDataUrl) {
      const fmt = settings.customFontFormat || 'woff2-variations';
      const css = `
@font-face {
  font-family: 'DynRTL Custom';
  src: url("${settings.customFontDataUrl}") format("${fmt}"),
       url("${settings.customFontDataUrl}");
  font-weight: 100 900;
  font-style: normal;
  font-display: swap;
}
:root { --dynrtl-font-stack: 'DynRTL Custom', 'Vazirmatn DynRTL', 'Vazirmatn', 'Tahoma', sans-serif; }
`;
      if (!style) {
        style = document.createElement('style');
        style.id = id;
        (document.head || document.documentElement).appendChild(style);
      }
      style.textContent = css;
    } else if (style) {
      style.remove();
    }
  }

  // ----- Activation ----------------------------------------------------

  function activate() {
    if (active) return;
    active = true;
    cooldownLevel = 0;
    recentTrips = [];
    log.log('activating on', location.hostname);
    applyCustomFont();
    const root = document.body || document.documentElement;
    if (root) {
      dirtyRoots.add(root);
      flushQueued = true;
      idle(flush);
      sweepInputs(root);
    }
    attachInputHandler();
    startObservers();
  }

  function deactivate() {
    if (!active) return;
    active = false;
    log.log('deactivating on', location.hostname);
    stopObservers();
    detachInputHandler();
    if (flushTimer) { clearTimeout(flushTimer); flushTimer = null; }
    if (cooldownTimer) { clearTimeout(cooldownTimer); cooldownTimer = null; }
    cooldownActive = false;
    flushQueued = false;
    dirtyRoots.clear();
    try {
      const els = document.querySelectorAll('.dynrtl-rtl, .dynrtl-rtl-input, .dynrtl-rtl-input-aligned');
      for (let i = 0; i < els.length; i++) {
        els[i].classList.remove('dynrtl-rtl');
        els[i].classList.remove('dynrtl-rtl-input');
        els[i].classList.remove('dynrtl-rtl-input-aligned');
      }
    } catch (_) {}
    const customStyle = document.getElementById('dynrtl-custom-font-style');
    if (customStyle) customStyle.remove();
  }

  function reconcile() {
    const enabled = isSiteEnabled(settings, location.hostname);
    if (enabled && !active) activate();
    else if (!enabled && active) deactivate();
    else if (enabled && active) applyCustomFont();
  }

  // ----- Settings ------------------------------------------------------

  function loadSettings() {
    return new Promise((resolve) => {
      try {
        api.storage.local.get(null, (stored) => {
          settings = Object.assign({}, DEFAULT_SETTINGS, stored || {});
          resolve(settings);
        });
      } catch (e) {
        log.error('failed to load settings', e);
        resolve(settings);
      }
    });
  }

  function onStorageChanged(changes, areaName) {
    if (areaName !== 'local') return;
    let touched = false;
    for (const key of Object.keys(changes)) {
      if (key in DEFAULT_SETTINGS) {
        settings[key] = changes[key].newValue !== undefined
          ? changes[key].newValue
          : DEFAULT_SETTINGS[key];
        touched = true;
      }
    }
    if (touched) reconcile();
  }
  api.storage.onChanged.addListener(onStorageChanged);

  api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || !msg.type) return;
    switch (msg.type) {
      case 'DYNRTL_GET_STATE':
        sendResponse({ host: location.hostname, active, settings });
        return true;
      case 'DYNRTL_RECONCILE':
        loadSettings().then(reconcile);
        sendResponse({ ok: true });
        return true;
      default:
        return;
    }
  });

  // ----- Boot ----------------------------------------------------------

  function bootstrap() {
    if (bootstrap.done) return;
    bootstrap.done = true;
    reconcile();
  }

  loadSettings().then(() => {
    log.log('settings loaded', settings);
    if (document.body) { bootstrap(); return; }
    document.addEventListener('DOMContentLoaded', bootstrap, { once: true });
    try {
      const mo = new MutationObserver(() => {
        if (document.body) { mo.disconnect(); bootstrap(); }
      });
      mo.observe(document.documentElement, { childList: true });
    } catch (_) {}
  });

  window.addEventListener('pagehide', () => {
    stopObservers();
    detachInputHandler();
    if (flushTimer) clearTimeout(flushTimer);
    if (cooldownTimer) clearTimeout(cooldownTimer);
  }, { once: true });
})();
