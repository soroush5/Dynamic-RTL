/* Dynamic RTL - Main content script.
 * Detects Persian / Arabic text, applies the .dynrtl-rtl class to display
 * containers, and uses dir="auto" + dynamic text-align for editable
 * elements (safer for editor frameworks). Walks shadow DOM. Observes
 * mutations for SPAs and chat apps.
 */
(function () {
  'use strict';

  if (window.__DYNRTL_MAIN_DONE__) return;
  window.__DYNRTL_MAIN_DONE__ = true;

  const core = window.__DYNRTL_CORE__;
  if (!core) return;

  const {
    api, RTL_REGEX, SKIP_TAGS, SKIP_SELECTORS,
    DEFAULT_SETTINGS, isSiteEnabled, makeLogger
  } = core;

  // ----- State ----------------------------------------------------------
  let settings = Object.assign({}, DEFAULT_SETTINGS);
  let active = false;
  const tagged = new WeakSet();
  const shadowRoots = new WeakSet(); // shadow roots we've already attached an observer to
  const pendingElements = new Set();
  let scheduled = false;
  let observers = []; // [light dom observer, shadow root observers...]
  let inputHandlerAttached = false;
  const log = makeLogger(() => settings.debug);

  // ----- Element helpers -----------------------------------------------

  function isSkippableElement(el) {
    if (!el || el.nodeType !== 1) return true;
    if (SKIP_TAGS.has(el.tagName)) return true;
    if (el.hasAttribute && el.hasAttribute('data-dynrtl-skip')) return true;
    if (el.closest && SKIP_SELECTORS.some(sel => {
      try { return el.closest(sel); } catch (_) { return false; }
    })) return true;
    return false;
  }

  // True when the element is part of an editing region (so we should not
  // apply our display CSS class - the input handler manages those via
  // dir="auto" instead). We require an explicit contenteditable=true|""|
  // plaintext-only attribute on a CLOSE ancestor (within 4 hops) to avoid
  // false positives on apps that put a global contenteditable=false on the
  // whole shell.
  function isInsideEditor(el) {
    let cur = el;
    for (let i = 0; cur && cur.nodeType === 1 && i < 6; i++) {
      const ce = cur.getAttribute && cur.getAttribute('contenteditable');
      if (ce === 'false') return false;
      if (ce === 'true' || ce === '' || ce === 'plaintext-only') return true;
      cur = cur.parentNode;
    }
    return false;
  }

  // Inline tag list - used to walk up to the nearest block ancestor.
  const INLINE_TAGS = new Set([
    'A','ABBR','B','BDI','BDO','BIG','BR','CITE','CODE','DATA','DFN','EM',
    'I','KBD','MARK','Q','S','SAMP','SMALL','SPAN','STRONG','SUB','SUP',
    'TIME','U','VAR','WBR','FONT'
  ]);

  function findBlockAncestor(el) {
    let cur = el;
    for (let i = 0; cur && i < 5; i++) {
      if (cur.nodeType !== 1) { cur = cur.parentNode; continue; }
      if (!INLINE_TAGS.has(cur.tagName)) return cur;
      cur = cur.parentNode;
    }
    return el && el.nodeType === 1 ? el : (el && el.parentElement);
  }

  // ----- Tagging --------------------------------------------------------

  function tagElement(el) {
    if (!el || el.nodeType !== 1) return;
    if (tagged.has(el)) return;
    if (isSkippableElement(el)) return;
    // Don't apply the heavy display class to editable elements - they get
    // dir="auto" + the lighter font class instead.
    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') return;
    if (isInsideEditor(el)) return;
    el.classList.add('dynrtl-rtl');
    tagged.add(el);
  }

  function processTextNode(textNode) {
    const v = textNode.nodeValue;
    if (!v) return;
    if (!RTL_REGEX.test(v)) return;
    const parent = textNode.parentElement;
    if (!parent || isSkippableElement(parent)) return;
    if (isInsideEditor(parent)) return;
    const target = findBlockAncestor(parent) || parent;
    tagElement(target);
  }

  // Walk light DOM subtree of an element using TreeWalker (fast).
  function walkLightSubtree(root, budget) {
    if (!root || root.nodeType !== 1) return budget;
    if (isSkippableElement(root)) return budget;
    const tw = document.createTreeWalker(
      root,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode(node) {
          const p = node.parentElement;
          if (!p || isSkippableElement(p)) return NodeFilter.FILTER_REJECT;
          if (isInsideEditor(p)) return NodeFilter.FILTER_REJECT;
          if (!node.nodeValue) return NodeFilter.FILTER_REJECT;
          return RTL_REGEX.test(node.nodeValue) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
        }
      }
    );
    let n;
    while ((n = tw.nextNode())) {
      processTextNode(n);
      budget--;
      if (budget <= 0) {
        log.warn('Walk capped; will continue on next mutation.');
        return budget;
      }
    }
    return budget;
  }

  // Recursively walk both light DOM and any open shadow roots reachable
  // from `root`. Open shadow roots are common in modern apps (e.g. some
  // Lit / Web Components based UIs).
  function walkSubtree(root) {
    if (!root) return;
    let budget = 5000;
    const stack = [root];
    while (stack.length) {
      const node = stack.pop();
      if (!node) continue;
      if (node.nodeType === 1) {
        if (isSkippableElement(node)) continue;
        if (node.shadowRoot) {
          attachShadowObserver(node.shadowRoot);
          stack.push(node.shadowRoot);
        }
        budget = walkLightSubtree(node, budget);
        if (budget <= 0) return;
        // Walk into descendant shadow hosts. querySelectorAll('*') is
        // expensive on huge trees, so guard it.
        if (node.querySelectorAll && node.children && node.children.length) {
          // Find any shadow hosts inside this subtree.
          // We rely on the fact that custom elements have a hyphen.
          let hosts;
          try {
            hosts = node.querySelectorAll('*');
          } catch (_) { hosts = []; }
          for (let i = 0; i < hosts.length; i++) {
            const h = hosts[i];
            if (h.shadowRoot && !shadowRoots.has(h.shadowRoot)) {
              stack.push(h);
            }
          }
        }
      } else if (node.nodeType === 11) {
        // ShadowRoot or DocumentFragment.
        for (let i = 0; i < node.childNodes.length; i++) {
          stack.push(node.childNodes[i]);
        }
      }
    }
  }

  // ----- Inputs / textarea / contenteditable ---------------------------

  function getEditableValue(el) {
    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') return el.value || '';
    try {
      const t = el.innerText || el.textContent || '';
      return t.length > 200 ? t.slice(0, 200) : t;
    } catch (_) {
      return '';
    }
  }

  function applyInputDir(el) {
    if (!el || el.nodeType !== 1) return;
    if (isSkippableElement(el)) return;
    const value = getEditableValue(el);
    const isRtl = !!value && RTL_REGEX.test(value);

    // Always ensure dir="auto" once we have seen this element. dir="auto"
    // is the W3C-recommended way to handle bidi inside inputs and does
    // not interfere with editor frameworks. We leave it set even on empty
    // inputs - it's a no-op for non-RTL content.
    try {
      if (el.getAttribute('dir') !== 'auto') el.setAttribute('dir', 'auto');
    } catch (_) {}

    // Always apply the font class once we have seen this element. Removing
    // and re-adding it on every keystroke causes layout thrash in editors.
    if (!el.classList.contains('dynrtl-rtl-input')) {
      el.classList.add('dynrtl-rtl-input');
    }

    // text-align is the bit that needs to flip live: dir="auto" handles
    // BIDI direction inside the input but does NOT change text-align, and
    // many sites pin text-align: left explicitly. So we toggle a class
    // that adds `text-align: right !important` only when the current
    // content actually has Persian / Arabic text.
    if (isRtl) {
      if (!el.classList.contains('dynrtl-rtl-input-aligned')) {
        el.classList.add('dynrtl-rtl-input-aligned');
      }
    } else if (el.classList.contains('dynrtl-rtl-input-aligned')) {
      el.classList.remove('dynrtl-rtl-input-aligned');
    }
  }

  function handleInputEvent(ev) {
    const t = ev.target;
    if (!t || !t.tagName) return;
    if (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable) {
      applyInputDir(t);
    }
  }

  function attachInputHandler() {
    if (inputHandlerAttached) return;
    inputHandlerAttached = true;
    document.addEventListener('input', handleInputEvent, true);
    document.addEventListener('focusin', handleInputEvent, true);
  }

  function detachInputHandler() {
    if (!inputHandlerAttached) return;
    inputHandlerAttached = false;
    document.removeEventListener('input', handleInputEvent, true);
    document.removeEventListener('focusin', handleInputEvent, true);
  }

  function sweepInputs(root) {
    const r = root && root.querySelectorAll ? root : document;
    if (!r.querySelectorAll) return;
    let nodes;
    try {
      nodes = r.querySelectorAll(
        'input, textarea, [contenteditable=""], [contenteditable="true"], [contenteditable="plaintext-only"]'
      );
    } catch (_) {
      return;
    }
    for (let i = 0; i < nodes.length; i++) applyInputDir(nodes[i]);
  }

  // ----- Scheduling ----------------------------------------------------
  //
  // We try to keep the main thread interactive while still walking the
  // DOM. Strategy:
  //   - First wake-up: requestIdleCallback (low-priority background work).
  //   - Inside a batch: yield to the scheduler between sub-batches using
  //     scheduler.yield() if the platform supports it (Chrome 129+),
  //     otherwise fall back to a microtask-equivalent.
  // This follows the modern-web-guidance content-scripts recommendation:
  // "batch with requestAnimationFrame and yield between batches".

  const idle = window.requestIdleCallback
    ? (cb) => window.requestIdleCallback(cb, { timeout: 200 })
    : (cb) => setTimeout(cb, 16);

  // True when scheduler.yield() is available (Chrome 129+, Firefox is
  // tracking it). When it is, we get cooperative-scheduling semantics
  // without blocking. Otherwise we fall back to a 0ms postTask via
  // setTimeout, which is the next-best yield primitive.
  const yieldToMain = (typeof scheduler !== 'undefined' && scheduler.yield)
    ? () => scheduler.yield()
    : () => new Promise((r) => setTimeout(r, 0));

  function schedule(el) {
    if (el) pendingElements.add(el);
    if (scheduled) return;
    scheduled = true;
    idle(flushPending);
  }

  async function flushPending() {
    scheduled = false;
    if (!active) { pendingElements.clear(); return; }
    const t0 = performance.now();
    const list = Array.from(pendingElements);
    pendingElements.clear();
    for (let i = 0; i < list.length; i++) {
      const el = list[i];
      try { walkSubtree(el); } catch (e) { log.error('walk failed', e); }
      // Per-batch ceiling: hand control back to the browser so input,
      // scroll, and frame paint don't get starved on big trees.
      if (performance.now() - t0 > 30) {
        for (let j = i + 1; j < list.length; j++) pendingElements.add(list[j]);
        scheduled = true;
        // Yield once before re-scheduling so the next idle slot reflects
        // the latest layout state. On older browsers this is a no-op
        // microtask hop.
        await yieldToMain();
        idle(flushPending);
        return;
      }
    }
    log.log('flush done in', (performance.now() - t0).toFixed(1), 'ms');
  }

  // ----- MutationObserver ---------------------------------------------

  function observerCallback(mutations) {
    if (!active) return;
    for (let i = 0; i < mutations.length; i++) {
      const m = mutations[i];
      if (m.type === 'childList') {
        const added = m.addedNodes;
        for (let j = 0; j < added.length; j++) {
          const n = added[j];
          if (n.nodeType === 1) {
            schedule(n);
            if (n.tagName === 'INPUT' || n.tagName === 'TEXTAREA' || n.isContentEditable) {
              applyInputDir(n);
            }
            if (n.shadowRoot) {
              attachShadowObserver(n.shadowRoot);
              schedule(n.shadowRoot);
            }
          } else if (n.nodeType === 3 && n.parentElement) {
            processTextNode(n);
          }
        }
      } else if (m.type === 'characterData') {
        if (m.target && m.target.nodeType === 3) {
          processTextNode(m.target);
        }
      }
    }
  }

  function attachShadowObserver(shadowRoot) {
    if (!shadowRoot || shadowRoots.has(shadowRoot)) return;
    shadowRoots.add(shadowRoot);
    try {
      const mo = new MutationObserver(observerCallback);
      mo.observe(shadowRoot, {
        subtree: true,
        childList: true,
        characterData: true
      });
      observers.push(mo);
      log.log('shadow observer attached');
    } catch (e) {
      log.error('failed to observe shadow root', e);
    }
  }

  function startObservers() {
    if (observers.length) return;
    const target = document.body || document.documentElement;
    if (!target) return;
    const mo = new MutationObserver(observerCallback);
    mo.observe(target, {
      subtree: true,
      childList: true,
      characterData: true
    });
    observers.push(mo);
    log.log('observer started');
  }

  function stopObservers() {
    for (const mo of observers) {
      try { mo.disconnect(); } catch (_) {}
    }
    observers = [];
  }

  // ----- Custom font ---------------------------------------------------

  function applyCustomFont() {
    const id = 'dynrtl-custom-font-style';
    let style = document.getElementById(id);
    if (settings.font === 'custom' && settings.customFontDataUrl) {
      const fmt = settings.customFontFormat || 'woff2-variations';
      const css = `
@font-face {
  font-family: 'DynRTL Custom';
  src: url("${settings.customFontDataUrl}") format("${fmt}"),
       url("${settings.customFontDataUrl}");
  font-weight: 100 900;
  font-style: normal;
  font-display: swap;
}
:root { --dynrtl-font-stack: 'DynRTL Custom', 'Vazirmatn DynRTL', 'Vazirmatn', 'Tahoma', sans-serif; }
`;
      if (!style) {
        style = document.createElement('style');
        style.id = id;
        (document.head || document.documentElement).appendChild(style);
      }
      style.textContent = css;
    } else if (style) {
      style.remove();
    }
  }

  // ----- Activation ----------------------------------------------------

  function activate() {
    if (active) return;
    active = true;
    log.log('activating on', location.hostname);
    applyCustomFont();
    const root = document.body || document.documentElement;
    if (root) {
      schedule(root);
      sweepInputs(root);
    }
    attachInputHandler();
    startObservers();
  }

  function deactivate() {
    if (!active) return;
    active = false;
    log.log('deactivating on', location.hostname);
    stopObservers();
    detachInputHandler();
    try {
      const els = document.querySelectorAll('.dynrtl-rtl, .dynrtl-rtl-input, .dynrtl-rtl-input-aligned');
      for (let i = 0; i < els.length; i++) {
        els[i].classList.remove('dynrtl-rtl');
        els[i].classList.remove('dynrtl-rtl-input');
        els[i].classList.remove('dynrtl-rtl-input-aligned');
      }
    } catch (_) {}
    const customStyle = document.getElementById('dynrtl-custom-font-style');
    if (customStyle) customStyle.remove();
  }

  function reconcile() {
    const enabled = isSiteEnabled(settings, location.hostname);
    if (enabled && !active) activate();
    else if (!enabled && active) deactivate();
    else if (enabled && active) applyCustomFont();
  }

  // ----- Settings ------------------------------------------------------

  function loadSettings() {
    return new Promise((resolve) => {
      try {
        api.storage.local.get(null, (stored) => {
          settings = Object.assign({}, DEFAULT_SETTINGS, stored || {});
          resolve(settings);
        });
      } catch (e) {
        log.error('failed to load settings', e);
        resolve(settings);
      }
    });
  }

  function onStorageChanged(changes, areaName) {
    if (areaName !== 'local') return;
    let touched = false;
    for (const key of Object.keys(changes)) {
      if (key in DEFAULT_SETTINGS) {
        settings[key] = changes[key].newValue !== undefined
          ? changes[key].newValue
          : DEFAULT_SETTINGS[key];
        touched = true;
      }
    }
    if (touched) reconcile();
  }
  api.storage.onChanged.addListener(onStorageChanged);

  api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || !msg.type) return;
    switch (msg.type) {
      case 'DYNRTL_GET_STATE':
        sendResponse({ host: location.hostname, active, settings });
        return true;
      case 'DYNRTL_RECONCILE':
        loadSettings().then(reconcile);
        sendResponse({ ok: true });
        return true;
      default:
        return;
    }
  });

  // ----- Boot ----------------------------------------------------------

  function bootstrap() {
    if (bootstrap.done) return;
    bootstrap.done = true;
    reconcile();
  }

  loadSettings().then(() => {
    log.log('settings loaded', settings);
    if (document.body) { bootstrap(); return; }
    document.addEventListener('DOMContentLoaded', bootstrap, { once: true });
    try {
      const mo = new MutationObserver(() => {
        if (document.body) { mo.disconnect(); bootstrap(); }
      });
      mo.observe(document.documentElement, { childList: true });
    } catch (_) {}
  });

  window.addEventListener('pagehide', () => {
    stopObservers();
    detachInputHandler();
  }, { once: true });
})();
